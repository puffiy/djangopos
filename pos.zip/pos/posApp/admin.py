from import_export.admin import ImportExportModelAdmin
from django.contrib import admin
from posApp.models import Category, Products, Sales, salesItems

# Register your models here.
# admin.site.register(Category)
#admin.site.register(Products)
admin.site.register(Sales)
admin.site.register(salesItems)
# admin.site.register(Employees)
# class TestNameResources(ImportExportModelAdmin):
#    pass

# admin.site.register(Test_Names,TestNameResources)

class TestNameResources(ImportExportModelAdmin):
   pass

admin.site.register(Category,TestNameResources)

class ProductResources(ImportExportModelAdmin):
   pass

admin.site.register(Products,ProductResources)